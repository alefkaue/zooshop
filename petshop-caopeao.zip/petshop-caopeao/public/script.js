// Aguardar o carregamento completo da página antes de executar o código
document.addEventListener('DOMContentLoaded', function () {
    console.log('🐕 Cãopeão - Sistema iniciado');

    const currentPage = window.location.pathname;

    if (currentPage.includes('login.html')) initLoginPage();
    else if (currentPage.includes('cadastro.html')) initCadastroPage();
    else if (currentPage.includes('dashboard.html')) initDashboardPage();

    addFormEffects();

    const telefoneInput = document.getElementById('telefone');
    if (telefoneInput) {
        telefoneInput.addEventListener('input', () => formatPhone(telefoneInput));
    }
});

// === INICIALIZAÇÃO DA PÁGINA DE LOGIN ===
function initLoginPage() {
    console.log('📋 Inicializando página de login');
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
}

// === FUNÇÃO PARA PROCESSAR LOGIN ===
async function handleLogin(event) {
    event.preventDefault();
    console.log('🔐 Processando login...');

    const formData = new FormData(event.target);
    const loginData = {
        email: formData.get('email'),
        senha: formData.get('senha')
    };

    console.log('📨 Dados coletados:', { email: loginData.email });

    const btn = event.submitter;
    const removeLoading = addLoadingToButton(btn, 'Entrar');

    try {
        showMessage('Fazendo login...', 'info');

        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginData)
        });

        if (!response.ok) throw new Error('Falha na requisição');

        const result = await response.json();
        console.log('📤 Resposta do servidor:', result);

        if (result.success) {
            showMessage(result.message, 'success');
            sessionStorage.setItem('user', JSON.stringify(result.usuario));
            sessionStorage.setItem('isLoggedIn', 'true');

            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        } else {
            showMessage(result.message, 'error');
            document.querySelector('#loginForm input[name="email"]').focus();
        }
    } catch (error) {
        console.error('❌ Erro no login:', error);
        showMessage('Erro de conexão. Tente novamente.', 'error');
    } finally {
        removeLoading();
    }
}

// === INICIALIZAÇÃO DA PÁGINA DE CADASTRO ===
function initCadastroPage() {
    console.log('📝 Inicializando página de cadastro');
    const cadastroForm = document.getElementById('cadastroForm');

    if (cadastroForm) {
        cadastroForm.addEventListener('submit', handleCadastro);

        const senhaInput = document.getElementById('senha');
        const confirmarSenhaInput = document.getElementById('confirmarSenha');

        if (confirmarSenhaInput) {
            confirmarSenhaInput.addEventListener('input', validatePasswordMatch);
        }
    }
}

// === FUNÇÃO PARA VALIDAR SE AS SENHAS COINCIDEM ===
function validatePasswordMatch() {
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;
    const confirmarSenhaInput = document.getElementById('confirmarSenha');

    if (confirmarSenha && senha !== confirmarSenha) {
        confirmarSenhaInput.style.borderColor = 'var(--error-color)';
        confirmarSenhaInput.setCustomValidity('As senhas não coincidem');
    } else {
        confirmarSenhaInput.style.borderColor = '';
        confirmarSenhaInput.setCustomValidity('');
    }
}

// === FUNÇÃO PARA PROCESSAR CADASTRO ===
async function handleCadastro(event) {
    event.preventDefault();
    console.log('📝 Processando cadastro...');

    const formData = new FormData(event.target);
    const senha = formData.get('senha');
    const confirmarSenha = formData.get('confirmarSenha');

    if (senha !== confirmarSenha) {
        showMessage('As senhas não coincidem', 'error');
        document.getElementById('confirmarSenha').focus();
        return;
    }

    const cadastroData = {
        nome: formData.get('nome'),
        email: formData.get('email'),
        senha: senha,
        telefone: formData.get('telefone')
    };

    console.log('📨 Dados coletados:', {
        nome: cadastroData.nome,
        email: cadastroData.email,
        telefone: cadastroData.telefone
    });

    const btn = event.submitter;
    const removeLoading = addLoadingToButton(btn, 'Cadastrar');

    try {
        showMessage('Criando sua conta...', 'info');

        const response = await fetch('/api/cadastro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cadastroData)
        });

        if (!response.ok) throw new Error('Falha na requisição');

        const result = await response.json();
        console.log('📤 Resposta do servidor:', result);

        if (result.success) {
            showMessage(result.message, 'success');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            showMessage(result.message, 'error');
        }
    } catch (error) {
        console.error('❌ Erro no cadastro:', error);
        showMessage('Erro de conexão. Tente novamente.', 'error');
    } finally {
        removeLoading();
    }
}

// === INICIALIZAÇÃO DO DASHBOARD ===
function initDashboardPage() {
    console.log('🏠 Inicializando dashboard');

    const isLoggedIn = sessionStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        console.log('⚠️ Usuário não logado, redirecionando...');
        window.location.href = 'login.html';
        return;
    }

    loadUserInfo();

    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

// === FUNÇÃO PARA CARREGAR INFORMAÇÕES DO USUÁRIO ===
function loadUserInfo() {
    try {
        const userData = sessionStorage.getItem('user');

        if (userData) {
            const user = JSON.parse(userData);
            const userNameElement = document.getElementById('userName');
            const welcomeMessageElement = document.getElementById('welcomeMessage');

            if (userNameElement) userNameElement.textContent = user.nome;
            if (welcomeMessageElement) {
                welcomeMessageElement.textContent = `Bem-vindo de volta, ${user.nome.split(' ')[0]}!`;
            }

            console.log('👤 Dados do usuário carregados:', {
                nome: user.nome,
                email: user.email
            });
        }
    } catch (error) {
        console.error('❌ Erro ao carregar dados do usuário:', error);
        handleLogout();
    }
}

// === FUNÇÃO PARA PROCESSAR LOGOUT ===
function handleLogout() {
    console.log('🚪 Fazendo logout...');
    sessionStorage.removeItem('user');
    sessionStorage.removeItem('isLoggedIn');
    window.location.href = 'index.html';
}

// === FUNÇÃO UTILITÁRIA PARA MOSTRAR MENSAGENS ===
function showMessage(message, type = 'info') {
    const messageElement = document.getElementById('message');

    if (!messageElement) {
        console.log(`📢 ${type.toUpperCase()}: ${message}`);
        return;
    }

    messageElement.className = 'message';
    messageElement.classList.add(type);
    messageElement.textContent = message;
    messageElement.classList.remove('hidden');

    if (type === 'success' || type === 'info') {
        setTimeout(() => {
            messageElement.classList.add('hidden');
        }, 5000);
    }

    console.log(`📢 ${type.toUpperCase()}: ${message}`);
}

// === FUNÇÃO UTILITÁRIA PARA VALIDAR EMAIL ===
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// === FUNÇÃO UTILITÁRIA PARA VALIDAR TELEFONE BRASILEIRO ===
function isValidPhone(phone) {
    const cleanPhone = phone.replace(/\D/g, '');
    return cleanPhone.length === 10 || cleanPhone.length === 11;
}

// === FORMATAÇÃO AUTOMÁTICA DE TELEFONE ===
function formatPhone(input) {
    let phone = input.value.replace(/\D/g, '');
    if (phone.length >= 6) {
        phone = phone.replace(/(\d{2})(\d{4,5})(\d{4})/, '($1) $2-$3');
    } else if (phone.length >= 2) {
        phone = phone.replace(/(\d{2})(\d{0,5})/, '($1) $2');
    }
    input.value = phone;
}

// === ADICIONAR EFEITOS AOS INPUTS ===
function addFormEffects() {
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('focus', function () {
            this.parentElement.classList.add('focused');
        });
        input.addEventListener('blur', function () {
            this.parentElement.classList.remove('focused');
        });
    });
}

// === ADICIONAR EFEITO DE LOADING AOS BOTÕES ===
function addLoadingToButton(button, originalText) {
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Carregando...';

    return function removeLoading() {
        button.disabled = false;
        button.innerHTML = originalText;
    };
}

// === INICIALIZAÇÃO DA PÁGINA DE AGENDAMENTO ===
function initAgendamentoPage() {
    console.log('📅 Inicializando página de agendamento');
    carregarTiposDePet();
}

// === FUNÇÃO PARA CARREGAR TIPOS DE PET ===
async function carregarTiposDePet() {
    const select = document.getElementById('tipoPet');
    if (!select) return;

    // Mostra opção de carregamento
    select.innerHTML = '<option value="">Carregando tipos de pets...</option>';

    try {
        const response = await fetch('/api/petType'); // <- Mude se a rota for diferente

        if (!response.ok) throw new Error('Erro na requisição');

        const tipos = await response.json();

        // Limpa e insere as opções
        select.innerHTML = '<option value="">Selecione o tipo</option>';
        tipos.forEach(tipo => {
            const option = document.createElement('option');
            option.value = tipo.id || tipo.nome;
            option.textContent = tipo.nome;
            select.appendChild(option);
        });

        console.log('✅ Tipos de pet carregados:', tipos);
    } catch (error) {
        console.error('❌ Falha ao carregar tipos de pet:', error);
        select.innerHTML = '<option value="">Erro ao carregar</option>';
    }
}

